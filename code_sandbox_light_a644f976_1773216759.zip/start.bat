@echo off
REM Remote Desktop System - Quick Start Script for Windows

echo 🚀 Starting Remote Desktop System...

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ Node.js is not installed. Please install Node.js first.
    exit /b 1
)

REM Check if npm is installed
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ npm is not installed. Please install npm first.
    exit /b 1
)

REM Install dependencies
echo 📦 Installing dependencies...
call npm install

REM Check if installation was successful
if %errorlevel% equ 0 (
    echo ✅ Dependencies installed successfully
) else (
    echo ❌ Failed to install dependencies
    exit /b 1
)

REM Start the server
echo 🖥️  Starting backend server...
echo 🌐 Server will be available at: http://localhost:3000
echo 📱 Open index.html in your browser to access the application
echo.
echo Instructions:
echo 1. Open http://localhost:3000/index.html in your browser
echo 2. Select 'Desktop Host' mode and click 'Start Hosting'
echo 3. Copy the Device ID that appears
echo 4. Open another browser tab/window and go to the same URL
echo 5. Select 'Mobile Client' mode and enter the Device ID
echo 6. Click 'Connect' to establish the remote desktop connection
echo.

node server.js