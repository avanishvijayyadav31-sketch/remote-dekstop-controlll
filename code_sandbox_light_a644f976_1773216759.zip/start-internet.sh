#!/bin/bash

# Remote Desktop System - Internet Access Setup (ngrok)

echo "🌐 Setting up internet access for mobile devices..."

# Check if ngrok is installed
if ! command -v ngrok &> /dev/null; then
    echo "❌ ngrok is not installed. Installing ngrok..."
    
    # Download and install ngrok
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        curl -sSL https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip -o ngrok.zip
        unzip ngrok.zip
        sudo mv ngrok /usr/local/bin/
        rm ngrok.zip
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        curl -sSL https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-darwin-amd64.zip -o ngrok.zip
        unzip ngrok.zip
        sudo mv ngrok /usr/local/bin/
        rm ngrok.zip
    else
        echo "❌ Please install ngrok manually from https://ngrok.com/download"
        exit 1
    fi
fi

# Start the Node.js server in background
echo "🚀 Starting Node.js server..."
npm start &
SERVER_PID=$!

# Wait for server to start
sleep 3

# Start ngrok tunnel
echo "🌐 Starting ngrok tunnel..."
echo "This will give you a public URL accessible from anywhere"
echo ""
echo "📱 Mobile users can access your remote desktop using the ngrok URL"
echo ""

ngrok http 3000

# Clean up when ngrok is stopped
echo "🧹 Cleaning up..."
kill $SERVER_PID 2>/dev/null