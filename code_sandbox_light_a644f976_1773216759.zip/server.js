const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

const PORT = process.env.PORT || 3000;

let hosts = new Map();
let clients = new Map();
let chatMessages = [];

app.get('/api/hosts', (req, res) => {
    const availableHosts = Array.from(hosts.entries()).map(([id, host]) => ({
        id,
        name: host.name || `Desktop-${id.substring(0, 8)}`,
        online: true
    }));
    res.json(availableHosts);
});

app.get('/api/chat/history', (req, res) => {
    res.json(chatMessages);
});

app.post('/api/chat/message', (req, res) => {
    const { message, sender, deviceId } = req.body;
    const chatMessage = {
        id: uuidv4(),
        message,
        sender,
        deviceId,
        timestamp: new Date().toISOString()
    };
    chatMessages.push(chatMessage);
    io.emit('chat-message', chatMessage);
    res.json({ success: true });
});

io.on('connection', (socket) => {
    console.log('New client connected:', socket.id);

    socket.on('register-host', (data) => {
        const deviceId = data.deviceId || uuidv4();
        socket.deviceId = deviceId;
        socket.role = 'host';
        
        hosts.set(deviceId, {
            socketId: socket.id,
            name: data.name || `Desktop-${deviceId.substring(0, 8)}`,
            deviceId,
            connected: false,
            clientId: null
        });
        
        console.log(`Host registered: ${deviceId}`, { deviceId, socketId: socket.id });
        socket.emit('host-registered', { deviceId });
        io.emit('devices-update', Array.from(hosts.entries()).map(([id, host]) => ({
            id,
            name: host.name,
            online: true
        })));
    });

    socket.on('register-client', (data) => {
        socket.role = 'client';
        socket.clientId = data.clientId || uuidv4();
        clients.set(socket.clientId, {
            socketId: socket.id,
            clientId: socket.clientId,
            connectedTo: null
        });
        console.log(`Client registered: ${socket.clientId}`);
    });

    socket.on('connect-to-host', (data) => {
        const { deviceId } = data;
        const host = hosts.get(deviceId);
        
        if (host && !host.connected) {
            host.connected = true;
            host.clientId = socket.clientId;
            
            const client = clients.get(socket.clientId);
            if (client) {
                client.connectedTo = deviceId;
            }
            
            socket.connectedTo = deviceId;
            
            socket.to(host.socketId).emit('client-connected', {
                clientId: socket.clientId
            });
            
            socket.emit('connection-established', {
                deviceId,
                status: 'connected'
            });
            
            console.log(`Client ${socket.clientId} connected to host ${deviceId}`);
        } else {
            socket.emit('connection-failed', {
                reason: host ? 'Host already connected' : 'Host not found'
            });
        }
    });

    socket.on('disconnect-from-host', () => {
        if (socket.connectedTo) {
            const host = hosts.get(socket.connectedTo);
            if (host) {
                host.connected = false;
                host.clientId = null;
                
                socket.to(host.socketId).emit('client-disconnected', {
                    clientId: socket.clientId
                });
                
                const client = clients.get(socket.clientId);
                if (client) {
                    client.connectedTo = null;
                }
                
                console.log(`Client ${socket.clientId} disconnected from host ${socket.connectedTo}`);
                socket.connectedTo = null;
            }
        }
    });

    socket.on('screen-data', (data) => {
        if (socket.role === 'host' && socket.connectedTo) {
            const client = Array.from(clients.values()).find(c => c.connectedTo === socket.deviceId);
            if (client) {
                io.to(client.socketId).emit('screen-update', data);
            }
        }
    });

    socket.on('mouse-event', (data) => {
        if (socket.role === 'client' && socket.connectedTo) {
            const host = hosts.get(socket.connectedTo);
            if (host) {
                socket.to(host.socketId).emit('remote-mouse', data);
            }
        }
    });

    socket.on('keyboard-event', (data) => {
        if (socket.role === 'client' && socket.connectedTo) {
            const host = hosts.get(socket.connectedTo);
            if (host) {
                socket.to(host.socketId).emit('remote-keyboard', data);
            }
        }
    });

    socket.on('file-transfer', (data) => {
        if (socket.role === 'client' && socket.connectedTo) {
            const host = hosts.get(socket.connectedTo);
            if (host) {
                socket.to(host.socketId).emit('file-transfer', data);
            }
        } else if (socket.role === 'host' && socket.connectedTo) {
            const client = Array.from(clients.values()).find(c => c.connectedTo === socket.deviceId);
            if (client) {
                io.to(client.socketId).emit('file-transfer', data);
            }
        }
    });

    socket.on('system-command', (data) => {
        if (socket.role === 'client' && socket.connectedTo) {
            const host = hosts.get(socket.connectedTo);
            if (host) {
                socket.to(host.socketId).emit('system-command', data);
            }
        }
    });

    socket.on('webrtc-offer', (data) => {
        if (socket.role === 'host' && socket.connectedTo) {
            const client = Array.from(clients.values()).find(c => c.connectedTo === socket.deviceId);
            if (client) {
                io.to(client.socketId).emit('webrtc-offer', data);
            }
        }
    });

    socket.on('webrtc-answer', (data) => {
        if (socket.role === 'client' && socket.connectedTo) {
            const host = hosts.get(socket.connectedTo);
            if (host) {
                socket.to(host.socketId).emit('webrtc-answer', data);
            }
        }
    });

    socket.on('webrtc-ice-candidate', (data) => {
        if (socket.role === 'host' && socket.connectedTo) {
            const client = Array.from(clients.values()).find(c => c.connectedTo === socket.deviceId);
            if (client) {
                io.to(client.socketId).emit('webrtc-ice-candidate', data);
            }
        } else if (socket.role === 'client' && socket.connectedTo) {
            const host = hosts.get(socket.connectedTo);
            if (host) {
                socket.to(host.socketId).emit('webrtc-ice-candidate', data);
            }
        }
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
        
        if (socket.role === 'host') {
            hosts.delete(socket.deviceId);
            io.emit('devices-update', Array.from(hosts.entries()).map(([id, host]) => ({
                id,
                name: host.name,
                online: true
            })));
        } else if (socket.role === 'client') {
            if (socket.connectedTo) {
                const host = hosts.get(socket.connectedTo);
                if (host) {
                    host.connected = false;
                    host.clientId = null;
                    socket.to(host.socketId).emit('client-disconnected', {
                        clientId: socket.clientId
                    });
                }
            }
            clients.delete(socket.clientId);
        }
    });
});

server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT}/index.html to access the application`);
});