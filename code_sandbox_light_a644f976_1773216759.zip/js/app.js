// Remote Desktop System - Main Application
class RemoteDesktopSystem {
    constructor() {
        this.isDesktop = true;
        this.isConnected = false;
        this.deviceId = null;
        this.backendClient = null;
        this.connectedDeviceId = null;
        this.localStream = null;
        this.remoteStream = null;
        this.chatMessages = [];
        this.currentMode = 'mouse';
        
        this.initializeApp();
    }

    generateDeviceId() {
        return 'RD-' + Math.random().toString(36).substr(2, 8).toUpperCase();
    }

    async initializeApp() {
        // Initialize backend client first
        this.backendClient = new BackendClient();
        this.deviceId = await this.backendClient.initialize();
        
        this.setupEventListeners();
        this.updateDeviceId();
        this.initializeTables();
    }

    setupEventListeners() {
        // Mode selection
        document.getElementById('desktopMode').addEventListener('click', () => this.switchMode(true));
        document.getElementById('mobileMode').addEventListener('click', () => this.switchMode(false));

        // Desktop controls
        document.getElementById('startHosting').addEventListener('click', () => this.startHosting());
        document.getElementById('stopHosting').addEventListener('click', () => this.stopHosting());

        // Mobile controls
        document.getElementById('connectBtn').addEventListener('click', () => this.connectToHost());
        document.getElementById('disconnectBtn').addEventListener('click', () => this.disconnectFromHost());

        // Control modes
        document.getElementById('mouseMode').addEventListener('click', () => this.setMode('mouse'));
        document.getElementById('keyboardMode').addEventListener('click', () => this.setMode('keyboard'));
        document.getElementById('chatMode').addEventListener('click', () => this.setMode('chat'));

        // System controls
        document.getElementById('shutdownBtn').addEventListener('click', () => this.sendSystemCommand('shutdown'));
        document.getElementById('restartBtn').addEventListener('click', () => this.sendSystemCommand('restart'));
        document.getElementById('lockBtn').addEventListener('click', () => this.sendSystemCommand('lock'));

        // Chat and text
        document.getElementById('sendChat').addEventListener('click', () => this.sendChatMessage());
        document.getElementById('sendText').addEventListener('click', () => this.sendTextInput());

        // File transfer
        document.getElementById('uploadBtn').addEventListener('click', () => document.getElementById('fileInput').click());
        document.getElementById('fileInput').addEventListener('change', (e) => this.handleFileUpload(e));

        // Remote screen interaction
        document.getElementById('remoteScreenImg').addEventListener('click', (e) => this.handleScreenClick(e));
        document.getElementById('remoteScreenImg').addEventListener('touchstart', (e) => this.handleTouchStart(e));

        // Keyboard input
        document.getElementById('chatInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendChatMessage();
        });
        document.getElementById('textInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendTextInput();
        });
    }

    updateDeviceId() {
        document.getElementById('deviceId').textContent = this.deviceId;
    }

    switchMode(isDesktop) {
        this.isDesktop = isDesktop;
        
        // Update UI
        document.getElementById('desktopMode').classList.toggle('bg-blue-600', isDesktop);
        document.getElementById('desktopMode').classList.toggle('bg-gray-600', !isDesktop);
        document.getElementById('mobileMode').classList.toggle('bg-blue-600', !isDesktop);
        document.getElementById('mobileMode').classList.toggle('bg-gray-600', isDesktop);
        
        document.getElementById('desktopView').classList.toggle('hidden', !isDesktop);
        document.getElementById('mobileView').classList.toggle('hidden', isDesktop);

        if (!isDesktop) {
            this.loadChatHistory();
        }
    }

    async startHosting() {
        try {
            this.log('Connecting to backend server...');
            await this.backendClient.connectToServer();
            this.backendClient.registerDevice();
            
            this.log('Starting host...');
            this.updateConnectionStatus('pending', 'Starting host...');

            // Generate screen stream
            const stream = await navigator.mediaDevices.getDisplayMedia({
                video: { mediaSource: 'screen' },
                audio: false
            });

            this.localStream = stream;
            document.getElementById('screenPreview').srcObject = stream;

            // Initialize WebRTC connection
            await this.backendClient.initializePeerConnection();

            this.updateConnectionStatus('connected', 'Host active - Device ID: ' + this.deviceId);
            document.getElementById('startHosting').classList.add('hidden');
            document.getElementById('stopHosting').classList.remove('hidden');

            this.log('Host started successfully');

        } catch (error) {
            console.error('Error starting host:', error);
            this.log('Error starting host: ' + error.message);
            this.updateConnectionStatus('disconnected', 'Host start failed');
        }
    }

    stopHosting() {
        this.log('Stopping host...');
        
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
        }

        if (this.backendClient) {
            this.backendClient.stopScreenCapture();
        }

        document.getElementById('screenPreview').srcObject = null;
        document.getElementById('startHosting').classList.remove('hidden');
        document.getElementById('stopHosting').classList.add('hidden');
        
        this.updateConnectionStatus('disconnected', 'Host stopped');
        this.log('Host stopped');
    }

    async initializePeerConnection() {
        const configuration = {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' }
            ]
        };

        this.peerConnection = new RTCPeerConnection(configuration);

        // Add local stream
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });
        }

        // Handle ICE candidates
        this.peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                this.simulateSocketSend('ice-candidate', event.candidate);
            }
        };

        // Handle remote stream
        this.peerConnection.ontrack = (event) => {
            this.remoteStream = event.streams[0];
            document.getElementById('remoteScreenImg').srcObject = this.remoteStream;
        };

        // Create data channel
        this.dataChannel = this.peerConnection.createDataChannel('remote-control');
        this.setupDataChannel();

        // Handle data channel from remote
        this.peerConnection.ondatachannel = (event) => {
            this.dataChannel = event.channel;
            this.setupDataChannel();
        };
    }

    setupDataChannel() {
        if (!this.dataChannel) return;

        this.dataChannel.onopen = () => {
            this.log('Data channel opened');
        };

        this.dataChannel.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleRemoteMessage(data);
        };

        this.dataChannel.onclose = () => {
            this.log('Data channel closed');
        };
    }

    async connectToHost() {
        const deviceId = document.getElementById('mobileDeviceId').value.trim();
        const password = document.getElementById('mobilePassword').value;

        if (!deviceId) {
            alert('Please enter a device ID');
            return;
        }

        this.log('Connecting to host: ' + deviceId);
        
        try {
            // Connect to backend server first
            await this.backendClient.connectToServer();
            this.backendClient.registerDevice();
            
            this.connectedDeviceId = deviceId;
            this.updateMobileConnectionStatus(true);

            // Initialize WebRTC and create offer
            await this.backendClient.initializePeerConnection();
            await this.backendClient.createOffer(deviceId);

            document.getElementById('connectionForm').classList.add('hidden');
            document.getElementById('remoteScreen').classList.remove('hidden');
            
            this.log('Connected to host: ' + deviceId);
            
        } catch (error) {
            console.error('Connection error:', error);
            alert('Connection failed: ' + error.message);
            this.updateMobileConnectionStatus(false);
        }
    }

    disconnectFromHost() {
        this.log('Disconnecting from host...');
        this.updateMobileConnectionStatus(false);
        
        document.getElementById('connectionForm').classList.remove('hidden');
        document.getElementById('remoteScreen').classList.add('hidden');
        
        if (this.backendClient) {
            this.backendClient.disconnect();
        }
        
        this.connectedDeviceId = null;
        this.log('Disconnected from host');
    }

    updateConnectionStatus(status, message) {
        const indicator = document.getElementById('statusIndicator');
        const statusText = document.getElementById('connectionStatus');
        
        indicator.className = `status-indicator status-${status}`;
        statusText.textContent = message;
    }

    updateMobileConnectionStatus(connected) {
        this.isConnected = connected;
        // Update mobile UI indicators if needed
    }

    setMode(mode) {
        this.currentMode = mode;
        
        // Update button states
        document.getElementById('mouseMode').classList.toggle('bg-blue-600', mode === 'mouse');
        document.getElementById('mouseMode').classList.toggle('bg-gray-600', mode !== 'mouse');
        document.getElementById('keyboardMode').classList.toggle('bg-blue-600', mode === 'keyboard');
        document.getElementById('keyboardMode').classList.toggle('bg-gray-600', mode !== 'keyboard');
        document.getElementById('chatMode').classList.toggle('bg-blue-600', mode === 'chat');
        document.getElementById('chatMode').classList.toggle('bg-gray-600', mode !== 'chat');

        // Show/hide relevant sections
        document.getElementById('keyboardInput').classList.toggle('hidden', mode !== 'keyboard');
        document.getElementById('chatSection').classList.toggle('hidden', mode !== 'chat');
    }

    handleScreenClick(event) {
        if (this.currentMode !== 'mouse') return;
        
        const rect = event.target.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / rect.width) * 100;
        const y = ((event.clientY - rect.top) / rect.height) * 100;

        this.sendRemoteCommand('mouse-click', { x, y });
    }

    handleTouchStart(event) {
        event.preventDefault();
        if (this.currentMode !== 'mouse') return;
        
        const rect = event.target.getBoundingClientRect();
        const touch = event.touches[0];
        const x = ((touch.clientX - rect.left) / rect.width) * 100;
        const y = ((touch.clientY - rect.top) / rect.height) * 100;

        this.sendRemoteCommand('touch-start', { x, y });
    }

    sendTextInput() {
        const text = document.getElementById('textInput').value;
        if (!text) return;

        this.sendRemoteCommand('text-input', { text });
        document.getElementById('textInput').value = '';
    }

    sendSystemCommand(command) {
        this.sendRemoteCommand('system-command', { command });
        this.log(`System command sent: ${command}`);
        alert(`System command sent: ${command}`);
    }

    sendRemoteCommand(type, data) {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            this.dataChannel.send(JSON.stringify({ type, data }));
        } else {
            // Simulate command sending
            this.log(`Command sent (${type}): ${JSON.stringify(data)}`);
        }
    }

    handleRemoteMessage(message) {
        switch (message.type) {
            case 'mouse-click':
                this.log(`Mouse click at ${message.data.x}, ${message.data.y}`);
                break;
            case 'text-input':
                this.log(`Text input: ${message.data.text}`);
                break;
            case 'system-command':
                this.log(`System command: ${message.data.command}`);
                break;
            case 'chat-message':
                this.receiveChatMessage(message.data);
                break;
        }
    }

    // Chat methods
    async sendChatMessage() {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();
        if (!message) return;

        const targetDeviceId = this.isDesktop ? this.connectedDeviceId : document.getElementById('mobileDeviceId').value;
        if (!targetDeviceId) return;

        const chatData = this.backendClient.sendChatMessage(message, targetDeviceId);
        input.value = '';
        this.displayChatMessage(chatData);
    }

    receiveChatMessage(messageData) {
        this.displayChatMessage(messageData);
    }

    displayChatMessage(messageData) {
        const chatContainer = document.getElementById('chatMessages');
        const messageElement = document.createElement('div');
        messageElement.className = `mb-2 p-2 rounded-lg ${messageData.sender === 'host' ? 'bg-blue-100 text-right' : 'bg-gray-100'}`;
        messageElement.innerHTML = `
            <div class="font-medium text-sm">${messageData.sender === 'host' ? 'Desktop' : 'Mobile'}</div>
            <div class="text-sm">${messageData.message}</div>
            <div class="text-xs text-gray-500">${new Date(messageData.timestamp).toLocaleTimeString()}</div>
        `;
        chatContainer.appendChild(messageElement);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // File transfer
    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const fileData = {
                name: file.name,
                size: file.size,
                type: file.type,
                data: e.target.result,
                timestamp: new Date().toISOString()
            };

            this.log(`File uploaded: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`);
            this.displayFile(fileData);
            
            // Send file to remote
            const targetDeviceId = this.isDesktop ? this.connectedDeviceId : document.getElementById('mobileDeviceId').value;
            if (targetDeviceId && this.backendClient) {
                this.backendClient.sendFile(fileData, targetDeviceId);
            }
        };
        reader.readAsDataURL(file);
    }

    displayFile(fileData) {
        const fileList = document.getElementById('fileList');
        const fileElement = document.createElement('div');
        fileElement.className = 'mb-2 p-2 bg-gray-100 rounded';
        fileElement.innerHTML = `
            <div class="font-medium">${fileData.name}</div>
            <div class="text-sm text-gray-600">${(fileData.size / 1024).toFixed(2)} KB</div>
            <a href="${fileData.data}" download="${fileData.name}" class="text-blue-600 text-sm hover:underline">Download</a>
        `;
        fileList.appendChild(fileElement);
    }

    // Simulation functions
    simulateSocketConnection() {
        this.log('Socket connection simulated');
        // In a real implementation, this would connect to an actual Socket.IO server
    }

    simulateSocketSend(event, data) {
        // In a real implementation, this would send via Socket.IO
        console.log('Socket send:', event, data);
    }

    async simulateConnection(deviceId) {
        // Simulate connection delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Simulate successful connection
        if (deviceId.length < 3) {
            throw new Error('Invalid device ID');
        }
        
        this.log(`Connected to device: ${deviceId}`);
    }

    startScreenSimulation() {
        // Simulate screen capture by updating the remote screen image
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 800;
        canvas.height = 600;

        const updateScreen = () => {
            if (!this.isConnected) return;

            // Create a simple screen simulation
            ctx.fillStyle = '#1e40af';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = '#ffffff';
            ctx.font = '24px Arial';
            ctx.fillText('Remote Desktop Screen', 50, 50);
            
            const time = new Date().toLocaleTimeString();
            ctx.fillText(`Time: ${time}`, 50, 100);
            ctx.fillText(`Device: ${document.getElementById('mobileDeviceId').value}`, 50, 130);

            // Add some visual elements
            ctx.fillStyle = '#10b981';
            ctx.fillRect(50, 200, 200, 100);
            ctx.fillStyle = '#ffffff';
            ctx.fillText('Active Window', 60, 250);

            // Update the image
            const img = document.getElementById('remoteScreenImg');
            img.src = canvas.toDataURL();
        };

        // Update every second
        this.screenUpdateInterval = setInterval(updateScreen, 1000);
        updateScreen();
    }

    // Table API functions
    async initializeTables() {
        try {
            // Initialize chat messages table
            await fetch('tables/chat_messages', {
                method: 'GET'
            });
        } catch (error) {
            // Table doesn't exist, create it
            const schema = {
                name: 'chat_messages',
                fields: [
                    { name: 'id', type: 'text', description: 'Unique identifier' },
                    { name: 'deviceId', type: 'text', description: 'Device ID' },
                    { name: 'message', type: 'text', description: 'Chat message' },
                    { name: 'sender', type: 'text', description: 'Message sender (host/client)' },
                    { name: 'timestamp', type: 'datetime', description: 'Message timestamp' }
                ]
            };

            // This would normally be done through the TableSchemaUpdate function
            console.log('Chat table schema would be created:', schema);
        }
    }

    async addChatMessage(messageData) {
        try {
            const response = await fetch('tables/chat_messages', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(messageData)
            });
            
            if (!response.ok) {
                throw new Error('Failed to save chat message');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error saving chat message:', error);
            // Continue without saving to table
            return messageData;
        }
    }

    async loadChatHistory() {
        try {
            const response = await fetch('tables/chat_messages?limit=50&sort=timestamp');
            if (!response.ok) {
                throw new Error('Failed to load chat history');
            }
            
            const data = await response.json();
            const messages = data.data || [];
            
            // Display messages
            messages.forEach(message => {
                this.displayChatMessage(message);
            });
        } catch (error) {
            console.error('Error loading chat history:', error);
        }
    }

    // Logging
    log(message) {
        const logContainer = document.getElementById('connectionLog');
        const timestamp = new Date().toLocaleTimeString();
        const logEntry = document.createElement('div');
        logEntry.className = 'mb-1';
        logEntry.innerHTML = `<span class="text-gray-500">[${timestamp}]</span> ${message}`;
        logContainer.appendChild(logEntry);
        logContainer.scrollTop = logContainer.scrollHeight;
        
        console.log(`[RemoteDesktop] ${message}`);
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.remoteDesktop = new RemoteDesktopSystem();
});