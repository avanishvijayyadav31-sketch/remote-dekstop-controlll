class BackendClient {
    constructor() {
        this.socket = null;
        this.deviceId = null;
        this.isConnected = false;
        this.isHost = false;
        this.isClient = false;
        this.connectedTo = null;
        this.peerConnection = null;
        this.localStream = null;
        this.remoteStream = null;
        this.dataChannel = null;
        this.onScreenUpdate = null;
        this.onConnectionEstablished = null;
        this.onConnectionClosed = null;
    }

    async initialize() {
        // Generate a unique device ID
        this.deviceId = this.generateDeviceId();
        console.log('BackendClient initialized with device ID:', this.deviceId);
        return this.deviceId;
    }

    async connectToServer() {
        return new Promise((resolve, reject) => {
            try {
                // Connect to the backend server
                this.socket = io();
                
                this.socket.on('connect', () => {
                    console.log('Connected to backend server');
                    this.isConnected = true;
                    resolve();
                });

                this.socket.on('disconnect', () => {
                    console.log('Disconnected from backend server');
                    this.isConnected = false;
                    if (this.onConnectionClosed) {
                        this.onConnectionClosed();
                    }
                });

                this.socket.on('error', (error) => {
                    console.error('Socket error:', error);
                    reject(error);
                });

                // Setup event handlers
                this.setupSocketHandlers();

            } catch (error) {
                console.error('Failed to connect to server:', error);
                reject(error);
            }
        });
    }

    setupSocketHandlers() {
        // Host registration response
        this.socket.on('host-registered', (data) => {
            console.log('Host registered:', data.deviceId);
            this.isHost = true;
            this.deviceId = data.deviceId;
            
            // Update UI with actual device ID
            if (window.remoteDesktop) {
                window.remoteDesktop.deviceId = data.deviceId;
                window.remoteDesktop.updateDeviceId();
            }
        });

        // Client registration response
        this.socket.on('client-registered', (data) => {
            console.log('Client registered:', data.clientId);
            this.isClient = true;
        });

        // Connection established
        this.socket.on('connection-established', (data) => {
            console.log('Connection established:', data);
            this.connectedTo = data.deviceId;
            if (this.onConnectionEstablished) {
                this.onConnectionEstablished(data);
            }
        });

        // Connection failed
        this.socket.on('connection-failed', (data) => {
            console.error('Connection failed:', data.reason);
            alert('Connection failed: ' + data.reason);
        });

        // Screen updates from host
        this.socket.on('screen-update', (data) => {
            if (this.onScreenUpdate) {
                this.onScreenUpdate(data);
            }
        });

        // Chat messages
        this.socket.on('chat-message', (message) => {
            this.handleChatMessage(message);
        });

        // File transfers
        this.socket.on('file-transfer', (data) => {
            this.handleFileTransfer(data);
        });

        // Remote commands
        this.socket.on('remote-mouse', (data) => {
            this.handleRemoteMouse(data);
        });

        this.socket.on('remote-keyboard', (data) => {
            this.handleRemoteKeyboard(data);
        });

        this.socket.on('system-command', (data) => {
            this.handleSystemCommand(data);
        });

        // WebRTC signaling
        this.socket.on('webrtc-offer', (data) => {
            this.handleWebRTCOffer(data);
        });

        this.socket.on('webrtc-answer', (data) => {
            this.handleWebRTCAnswer(data);
        });

        this.socket.on('webrtc-ice-candidate', (data) => {
            this.handleWebRTCIceCandidate(data);
        });

        // Device updates
        this.socket.on('devices-update', (devices) => {
            console.log('Devices updated:', devices);
            // Handle device list updates for mobile client
            if (window.remoteDesktop && !window.remoteDesktop.isDesktop) {
                window.remoteDesktop.availableDevices = devices;
                window.remoteDesktop.displayAvailableDevices();
            }
        });
    }

    generateDeviceId() {
        return 'device_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now().toString(36);
    }

    registerDevice() {
        if (this.isHost) {
            console.log('Registering as host with device ID:', this.deviceId);
            this.socket.emit('register-host', { deviceId: this.deviceId, name: 'Desktop Host' });
        } else {
            console.log('Registering as client with device ID:', this.deviceId);
            this.socket.emit('register-client', { clientId: this.deviceId });
        }
    }

    // Host functions
    async startScreenCapture() {
        try {
            // Try to get display media
            const stream = await navigator.mediaDevices.getDisplayMedia({
                video: {
                    width: { ideal: 1920 },
                    height: { ideal: 1080 },
                    frameRate: { ideal: 30 }
                },
                audio: false
            });

            this.localStream = stream;
            
            // Handle stream end
            stream.getVideoTracks()[0].onended = () => {
                console.log('Screen capture ended');
                this.stopScreenCapture();
            };

            // Start sending screen data
            this.startScreenSharing();

            return stream;
        } catch (error) {
            console.error('Error starting screen capture:', error);
            throw error;
        }
    }

    stopScreenCapture() {
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
        }
        this.isHost = false;
    }

    startScreenSharing() {
        // Create a canvas to capture frames
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const video = document.createElement('video');
        video.srcObject = this.localStream;
        video.play();

        video.onloadedmetadata = () => {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;

            // Capture and send frames
            const captureFrame = () => {
                if (this.localStream && video.readyState === 4) {
                    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                    const imageData = canvas.toDataURL('image/jpeg', 0.8);
                    
                    // Send to connected clients
                    this.socket.emit('screen-data', { 
                        imageData, 
                        deviceId: this.deviceId,
                        timestamp: Date.now()
                    });
                }
                
                if (this.localStream) {
                    requestAnimationFrame(captureFrame);
                }
            };

            captureFrame();
        };
    }

    // Client functions
    async connectToHost(deviceId) {
        if (!this.isConnected) {
            throw new Error('Not connected to server');
        }

        console.log('Connecting to host:', deviceId);
        this.connectedTo = deviceId;
        this.socket.emit('connect-to-host', { deviceId });
        
        return new Promise((resolve, reject) => {
            // Wait for connection confirmation
            const timeout = setTimeout(() => {
                reject(new Error('Connection timeout'));
            }, 10000);

            this.socket.once('connection-established', (data) => {
                clearTimeout(timeout);
                console.log('Connection established with host:', data.deviceId);
                if (this.onConnectionEstablished) {
                    this.onConnectionEstablished(data);
                }
                resolve(data);
            });

            this.socket.once('connection-failed', (data) => {
                clearTimeout(timeout);
                reject(new Error(data.reason));
            });
        });
    }

    disconnect() {
        if (this.connectedTo) {
            this.socket.emit('disconnect-from-host');
            this.connectedTo = null;
        }
        
        if (this.peerConnection) {
            this.peerConnection.close();
            this.peerConnection = null;
        }
    }

    // Remote control functions
    sendRemoteCommand(command, data) {
        if (!this.connectedTo) {
            console.warn('Not connected to a host');
            return;
        }

        const message = {
            command,
            data,
            deviceId: this.deviceId,
            timestamp: Date.now()
        };

        switch (command) {
            case 'mouse-click':
            case 'touch-start':
                this.socket.emit('mouse-event', message);
                break;
            case 'text-input':
                this.socket.emit('keyboard-event', message);
                break;
            case 'system-command':
                this.socket.emit('system-command', message);
                break;
            default:
                console.warn('Unknown command:', command);
        }
    }

    // Chat functions
    sendChatMessage(message, targetDeviceId) {
        const chatData = {
            id: this.generateMessageId(),
            message: message,
            sender: 'mobile',
            deviceId: targetDeviceId,
            timestamp: new Date().toISOString()
        };

        // Send through socket
        this.socket.emit('chat-message', chatData);

        return chatData;
    }

    handleChatMessage(message) {
        // Handle incoming chat message
        if (window.remoteDesktop) {
            window.remoteDesktop.displayChatMessage(message);
        }
    }

    // File transfer functions
    sendFile(fileData, targetDeviceId) {
        const fileTransfer = {
            id: this.generateMessageId(),
            fileData: fileData,
            deviceId: targetDeviceId,
            sender: this.deviceId,
            timestamp: new Date().toISOString()
        };

        this.socket.emit('file-transfer', fileTransfer);
    }

    handleFileTransfer(data) {
        // Handle incoming file transfer
        if (window.remoteDesktop) {
            window.remoteDesktop.displayFile(data.fileData);
        }
    }

    // WebRTC functions
    async initializePeerConnection() {
        const configuration = {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' }
            ]
        };

        this.peerConnection = new RTCPeerConnection(configuration);

        this.peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                this.socket.emit('webrtc-ice-candidate', {
                    candidate: event.candidate,
                    deviceId: this.connectedTo
                });
            }
        };

        this.peerConnection.ontrack = (event) => {
            console.log('Remote stream received');
            this.remoteStream = event.streams[0];
            if (window.remoteDesktop) {
                const videoElement = document.getElementById('remoteScreenImg');
                videoElement.srcObject = this.remoteStream;
            }
        };

        this.peerConnection.ondatachannel = (event) => {
            this.dataChannel = event.channel;
            this.setupDataChannel();
        };

        return this.peerConnection;
    }

    setupDataChannel() {
        if (!this.dataChannel) return;

        this.dataChannel.onopen = () => {
            console.log('Data channel opened');
        };

        this.dataChannel.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleDataChannelMessage(data);
        };

        this.dataChannel.onclose = () => {
            console.log('Data channel closed');
        };
    }

    handleDataChannelMessage(data) {
        switch (data.type) {
            case 'screen-update':
                if (this.onScreenUpdate) {
                    this.onScreenUpdate(data);
                }
                break;
            case 'chat-message':
                this.handleChatMessage(data);
                break;
            case 'file-transfer':
                this.handleFileTransfer(data);
                break;
            default:
                console.warn('Unknown data channel message:', data);
        }
    }

    async createOffer(deviceId) {
        if (!this.peerConnection) {
            await this.initializePeerConnection();
        }

        // Create data channel
        const dataChannel = this.peerConnection.createDataChannel('remote-desktop');
        this.dataChannel = dataChannel;
        this.setupDataChannel();

        const offer = await this.peerConnection.createOffer();
        await this.peerConnection.setLocalDescription(offer);

        this.socket.emit('webrtc-offer', {
            offer: offer,
            deviceId: deviceId
        });
    }

    async handleWebRTCOffer(data) {
        if (!this.peerConnection) {
            await this.initializePeerConnection();
        }

        await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
        const answer = await this.peerConnection.createAnswer();
        await this.peerConnection.setLocalDescription(answer);

        this.socket.emit('webrtc-answer', {
            answer: answer,
            deviceId: data.deviceId
        });
    }

    async handleWebRTCAnswer(data) {
        if (this.peerConnection) {
            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
        }
    }

    async handleWebRTCIceCandidate(data) {
        if (this.peerConnection) {
            await this.peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
        }
    }

    // Remote command handlers
    handleRemoteMouse(data) {
        // Handle remote mouse events on host
        console.log('Remote mouse event:', data);
        // This would be implemented to actually control the host's mouse
    }

    handleRemoteKeyboard(data) {
        // Handle remote keyboard events on host
        console.log('Remote keyboard event:', data);
        // This would be implemented to actually control the host's keyboard
    }

    handleSystemCommand(data) {
        // Handle system commands on host
        console.log('System command:', data);
        // This would be implemented to actually execute system commands
        
        // For demo purposes, just log and show notification
        if (window.remoteDesktop) {
            window.remoteDesktop.log(`System command received: ${data.command}`);
        }
    }

    // Utility functions
    generateMessageId() {
        return 'msg_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now().toString(36);
    }

    // Getters
    get isConnectedToHost() {
        return this.connectedTo !== null;
    }

    get currentDeviceId() {
        return this.deviceId;
    }

    get connectedHostId() {
        return this.connectedTo;
    }

    get connectedHostId() {
        return this.connectedTo;
    }
}