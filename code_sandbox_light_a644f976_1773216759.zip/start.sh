#!/bin/bash

# Remote Desktop System - Quick Start Script

echo "🚀 Starting Remote Desktop System..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if installation was successful
if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Start the server
echo "🖥️  Starting backend server..."
echo "🌐 Server will be available at: http://localhost:3000"
echo "📱 Open index.html in your browser to access the application"
echo ""
echo "Instructions:"
echo "1. Open http://localhost:3000/index.html in your browser"
echo "2. Select 'Desktop Host' mode and click 'Start Hosting'"
echo "3. Copy the Device ID that appears"
echo "4. Open another browser tab/window and go to the same URL"
echo "5. Select 'Mobile Client' mode and enter the Device ID"
echo "6. Click 'Connect' to establish the remote desktop connection"
echo ""

node server.js